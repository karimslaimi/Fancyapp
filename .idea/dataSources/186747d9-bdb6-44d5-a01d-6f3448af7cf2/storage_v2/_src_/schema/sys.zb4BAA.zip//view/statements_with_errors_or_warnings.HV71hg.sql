create definer = `mariadb.sys`@localhost view statements_with_errors_or_warnings as
select `sys`.`format_statement`(`performance_schema`.`events_statements_summary_by_digest`.`DIGEST_TEXT`)  AS `query`,
       `performance_schema`.`events_statements_summary_by_digest`.`SCHEMA_NAME`                            AS `db`,
       `performance_schema`.`events_statements_summary_by_digest`.`COUNT_STAR`                             AS `exec_count`,
       `performance_schema`.`events_statements_summary_by_digest`.`SUM_ERRORS`                             AS `errors`,
       ifnull(`performance_schema`.`events_statements_summary_by_digest`.`SUM_ERRORS` /
              nullif(`performance_schema`.`events_statements_summary_by_digest`.`COUNT_STAR`, 0), 0) *
       100                                                                                                 AS `error_pct`,
       `performance_schema`.`events_statements_summary_by_digest`.`SUM_WARNINGS`                           AS `warnings`,
       ifnull(`performance_schema`.`events_statements_summary_by_digest`.`SUM_WARNINGS` /
              nullif(`performance_schema`.`events_statements_summary_by_digest`.`COUNT_STAR`, 0), 0) *
       100                                                                                                 AS `warning_pct`,
       `performance_schema`.`events_statements_summary_by_digest`.`FIRST_SEEN`                             AS `first_seen`,
       `performance_schema`.`events_statements_summary_by_digest`.`LAST_SEEN`                              AS `last_seen`,
       `performance_schema`.`events_statements_summary_by_digest`.`DIGEST`                                 AS `digest`
from `performance_schema`.`events_statements_summary_by_digest`
where `performance_schema`.`events_statements_summary_by_digest`.`SUM_ERRORS` > 0
   or `performance_schema`.`events_statements_summary_by_digest`.`SUM_WARNINGS` > 0
order by `performance_schema`.`events_statements_summary_by_digest`.`SUM_ERRORS` desc,
         `performance_schema`.`events_statements_summary_by_digest`.`SUM_WARNINGS` desc;

-- comment on column statements_with_errors_or_warnings.db not supported: Database name. Records are summarised together with DIGEST.

-- comment on column statements_with_errors_or_warnings.exec_count not supported: Number of summarized events

-- comment on column statements_with_errors_or_warnings.errors not supported: Sum of the ERRORS column in the events_statements_current table.

-- comment on column statements_with_errors_or_warnings.warnings not supported: Sum of the WARNINGS column in the events_statements_current table.

-- comment on column statements_with_errors_or_warnings.first_seen not supported: Time at which the digest was first seen.

-- comment on column statements_with_errors_or_warnings.last_seen not supported: Time at which the digest was most recently seen.

-- comment on column statements_with_errors_or_warnings.digest not supported: Performance Schema digest. Records are summarised together with SCHEMA NAME.

